# Dynamic Website Data
home_title = 'Home'
articles_title = 'Articles'
about = 'Hello <b>werthtgrfe</b> and weclome to our site we\'ll write about technology and python, hope enjoy it and they\'re helpful for u'
header_h = 'WEBSITE'
header_p = 'Know more about technology and specially Python and Js'
telegram = 'https://t.me/amirilf'
instagram = 'https://instagram.com/amirilf'
github = 'https://github.com/amirilf'
